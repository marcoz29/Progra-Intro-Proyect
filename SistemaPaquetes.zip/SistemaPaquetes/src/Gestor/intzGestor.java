/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Gestor;

import Clases.Clientes;
import java.util.ArrayList;

/**
 *
 * @author ariel
 */
public interface intzGestor {
    
    //clientes
    public boolean GuardarClientes(Clientes myCliente);
    public boolean ModificarCliente(Clientes myCliente);
    public Clientes ConsultarClientes(int Id);
    public ArrayList<Clientes> ListarClientes();
    
}

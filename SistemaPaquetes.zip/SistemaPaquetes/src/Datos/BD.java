/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import Clases.Clientes;
import java.util.ArrayList;

/**
 *
 * @author ariel
 */
public class BD {
    
    
    //se crea el arraylist para almacenar la informacion de los clientes
    public static ArrayList<Clientes> tbl_Clientes = new ArrayList<Clientes>();
}
